﻿namespace DefiningClasses
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var person = new Person("Pesho",16);
        }
    }
}
