﻿using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> persons;
        public Family()
        {
            this.persons = new List<Person>();
        }

        public void AddMember(Person member)
        {
            this.persons.Add(member);
        }

        public Person GetOldestMember()
        {
           var person = persons.OrderByDescending(p => p.Age).FirstOrDefault();

            return person;
        }


    }
}
