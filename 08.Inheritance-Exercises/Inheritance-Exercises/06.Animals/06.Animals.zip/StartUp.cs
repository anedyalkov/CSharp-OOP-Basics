﻿namespace _06.Animals
{
    using _06.Animals.Animals;
    using _06.Animals.Core;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();            
        }
    }
}
