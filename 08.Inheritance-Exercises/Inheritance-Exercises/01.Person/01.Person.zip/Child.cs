﻿namespace _01.Person
{
    using System;

    public class Child:Person
    {
        const int MAX_AGE = 15;

        public override int Age
        {
            get { return base.Age; }
            set
            {
                if (value > MAX_AGE)
                {
                    throw new ArgumentException($"Child's age must be less than {MAX_AGE}!");
                }
                base.Age = value;
            }
        }

        public Child(string name, int age):base(name,age)
        {

        }
    }
}
