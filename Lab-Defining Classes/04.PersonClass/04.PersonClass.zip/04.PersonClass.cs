﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        //var account = new BankAccount();

        //var person = new Person("Pesho",19);

        //var firstAccount = new BankAccount();
        //firstAccount.Deposit(20);
        //var secondAccount = new BankAccount();
        //secondAccount.Deposit(10);
        //var thirdAccount = new BankAccount();
        //thirdAccount.Deposit(30);

        //var accounts = new List<BankAccount>
        //{
        //    firstAccount,
        //    secondAccount,
        //    thirdAccount,
        //};

        //var secondPerson = new Person("Misho", 20, accounts);

        //var result = secondPerson.GetBalance();

        //Console.WriteLine($"{result}");
    }
}

