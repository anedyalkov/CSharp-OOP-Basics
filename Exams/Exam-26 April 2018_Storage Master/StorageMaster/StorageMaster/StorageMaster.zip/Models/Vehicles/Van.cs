﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.Models.Vehicles
{
    public class Van : Vehicle
    {
        public Van() : base(2)
        {
        }
    }
}
