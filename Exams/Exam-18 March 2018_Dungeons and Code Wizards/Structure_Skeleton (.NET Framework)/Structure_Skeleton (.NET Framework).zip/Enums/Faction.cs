﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonsAndCodeWizards.Enums
{
    public enum Faction
    {
        CSharp,Java
    }
}
