﻿namespace StorageMaster.Models.Vehicles
{
    public class Van : Vehicle
    {
        public Van() : base(capacity: 2)
        {
        }
    }
}
