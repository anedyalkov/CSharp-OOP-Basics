﻿namespace StorageMaster.Models.Vehicles
{
    public class Semi : Vehicle
    {
        public Semi() : base(capacity: 10)
        {
        }
    }
}
