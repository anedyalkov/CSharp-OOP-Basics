﻿namespace StorageMaster.Models.Vehicles
{
    public class Truck : Vehicle
    {
        public Truck() : base(capacity: 5)
        {
        }
    }
}
