﻿namespace _05.BorderControl.Contracts
{
    public interface IInhabitant
    {
        string Id { get; }
    }
}
