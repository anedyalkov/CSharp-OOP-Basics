﻿namespace _03.Ferrari
{
    using _03.Ferrari.Core;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
