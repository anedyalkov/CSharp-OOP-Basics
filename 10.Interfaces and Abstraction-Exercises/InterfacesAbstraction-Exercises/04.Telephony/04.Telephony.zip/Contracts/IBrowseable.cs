﻿namespace _04.Telephony.Contracts
{
    public interface IBrowseable
    {
        string Browse();
    }
}
