﻿using _04.Telephony.Core;

namespace _04.Telephony
{
    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
