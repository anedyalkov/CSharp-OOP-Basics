﻿namespace _08.MilitaryElite.Contracts
{
    public interface ISoldier
    {
        int Id { get; }
        string FirstName { get; }
        string LastName { get; }
    }
}
