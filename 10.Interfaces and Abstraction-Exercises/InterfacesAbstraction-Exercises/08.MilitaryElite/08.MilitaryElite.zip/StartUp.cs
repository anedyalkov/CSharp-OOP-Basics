﻿namespace _08.MilitaryElite
{
    using _08.MilitaryElite.Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
