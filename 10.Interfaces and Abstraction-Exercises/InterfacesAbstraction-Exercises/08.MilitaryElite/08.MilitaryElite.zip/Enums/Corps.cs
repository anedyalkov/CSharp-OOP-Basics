﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
