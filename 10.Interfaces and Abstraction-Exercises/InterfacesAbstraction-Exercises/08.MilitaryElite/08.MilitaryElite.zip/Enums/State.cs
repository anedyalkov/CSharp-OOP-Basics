﻿namespace _08.MilitaryElite.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
