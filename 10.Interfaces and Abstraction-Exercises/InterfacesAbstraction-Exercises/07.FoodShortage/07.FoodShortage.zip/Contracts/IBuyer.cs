﻿namespace _07.FoodShortage.Contracts
{
    public interface IBuyer
    {
        int Food { get; }
        void BuyFood();
    }
}
