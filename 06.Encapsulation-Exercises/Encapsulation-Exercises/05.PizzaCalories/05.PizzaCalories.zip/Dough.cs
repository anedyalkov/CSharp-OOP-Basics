﻿namespace _05.PizzaCalories
{
    using System;

    public class Dough
    {
        private string flourType;
        private string bakingTechnique;
        private double weight;
        private double caloriesPerGram;

        public Dough(string flourType, string bakingTechnique, double weight)
        {
            FlourType = flourType;
            BakingTechnique = bakingTechnique;
            Weight = weight;
            caloriesPerGram = 2;
        }

        public string FlourType
        {
            get { return flourType; }
            private set
            {
                if (value != "white" && value != "wholegrain")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }
                flourType = value;
            }
        }

       
        public string BakingTechnique
        {
            get { return bakingTechnique; }
            private set
            {
                if (value != "crispy" && value != "chewy" && value != "homemade")
                {
                    throw new Exception("Invalid type of dough.");
                }
                bakingTechnique = value;
            }
        }

        public double Weight
        {
            get { return weight; }
            private set
            {
                if (value < 1 || value > 200)
                {
                    throw new ArgumentException("Dough weight should be in the range [1..200].");
                }
                weight = value;
            }
        }

        public double CalculateCaloriesPerGram()
        {
            var flourModifier = 0.0;
            var bakingTechniqueModifier = 0.0;
            var result = 0.0;
            switch (FlourType)
            {
                case "white":
                    flourModifier = 1.5;
                    break;
                case "wholegrain":
                    flourModifier = 1;
                    break;
                default:
                    break;
            }

            switch (BakingTechnique)
            {
                case "crispy":
                    bakingTechniqueModifier = 0.9;
                    break;
                case "chewy":
                    bakingTechniqueModifier = 1.1;
                    break;
                case "homemade":
                    bakingTechniqueModifier = 1;
                    break;
                default:
                    break;
            }

            result = (caloriesPerGram * weight) * flourModifier * bakingTechniqueModifier;
            return result;
        }

    }
}
