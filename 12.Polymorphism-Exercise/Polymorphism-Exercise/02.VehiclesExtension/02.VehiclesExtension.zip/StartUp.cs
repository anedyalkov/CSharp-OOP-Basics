﻿namespace _02.VehiclesExtension
{
    using _02.VehiclesExtension.Core;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
