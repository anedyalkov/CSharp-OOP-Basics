﻿namespace _03.WildFarm
{
    using _03.WildFarm.Core;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
