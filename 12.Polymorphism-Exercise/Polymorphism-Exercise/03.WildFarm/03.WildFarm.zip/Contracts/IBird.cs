﻿namespace _03.WildFarm.Contracts
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}
