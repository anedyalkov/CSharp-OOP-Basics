﻿namespace _03.WildFarm.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
