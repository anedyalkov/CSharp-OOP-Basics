﻿namespace _03.WildFarm.Core
{
    using _03.WildFarm.Contracts;
    using _03.WildFarm.Factories;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Engine
    {
        private AnimalFactory animalFactory;
        private FoodFactory foodFactory;
        private IAnimal animal;
        private IFood food;
        private List<IAnimal> animals;
        public Engine()
        {
            animalFactory = new AnimalFactory();
            foodFactory = new FoodFactory();
            animals = new List<IAnimal>();
        }
        public void Run()
        {
            string input;
            var countLines = 0;
            while ((input = Console.ReadLine()) != "End")
            {
                try
                {
                    if (countLines % 2 == 0)
                    {
                       
                            var animalInfo = input.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
                            animal = animalFactory.CreateAnimal(animalInfo);
                            countLines++;
                            continue;
                      
                    }
                    else
                    {
                       
                            var foodInfo = input.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
                            food = foodFactory.CreateFood(foodInfo);
                            countLines++;
                     

                    }

                    Console.WriteLine(animal.ProduceSound());
                    animal.Eat(food);
                    animals.Add(animal);
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
                
            }

            animals.ForEach(a => Console.WriteLine(a));
        }
    }
}
